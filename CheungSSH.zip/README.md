# CheungSSH
比Ansibel更好用的自动化工具
这是我（张其川 Cheung Kei-Chuen） 自主开发的基于 SSH协议的自动操作工具，比Ansible更轻量！操作更简单！
如果您觉得本软件还不错，有需要的话，请与我联系，包括有任何的使用疑问
我的QQ   2418731289

详细的用法介绍请： http://blog.chinaunix.net/uid-29295703-id-4663051.html
如果有任何试用疑问，请联系我！！
